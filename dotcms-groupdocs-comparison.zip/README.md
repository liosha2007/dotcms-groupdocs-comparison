dotcms-groupdocs-comparison-source
==================================

DotCms Groupdocs Comparison Source

```
${GroupDocsComparison.RenderIframe('your_compare_key', 'your_compare_file_guid', 800, 600)}
```